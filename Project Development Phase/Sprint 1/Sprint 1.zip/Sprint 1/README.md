# Sprint 1

## Current Status (AS OF 28 Oct 2022 13:00)
- [x] Registration - 100%
- [x] Confirmation Email - 75% (DEBUGGING)
- [x] Authentication - 100%
- [x] Login - 100%
- [x] Dashboard - 100%

## Hosted on Netlify
[child-safety.netlify.app](https://child-safety.netlify.app)